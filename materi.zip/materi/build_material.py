from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
from xml.etree import ElementTree as ET

ROOT = Path(__file__).parent
DOCS = ROOT / "Dokumen_Word"
SCRIPTS = ROOT / "Kode_Python"

LESSONS = [
    {
        "title": "Mengenal Deep Learning",
        "summary": "Deep learning adalah bagian dari machine learning yang memakai jaringan saraf berlapis untuk mempelajari pola dari data. Kita mulai dari ide prediksi, ukuran kesalahan, dan alur kerja sederhana.",
        "goals": ["Membedakan AI, machine learning, dan deep learning secara sederhana.", "Memahami bahwa model menerima masukan, menghitung prediksi, lalu membandingkannya dengan jawaban."],
        "terms": "data, model, prediksi, bobot, loss",
        "examples": [
            ("prediksi_dengan_bobot", "Melihat bagaimana satu masukan dikalikan bobot untuk menghasilkan prediksi sederhana.", '''x = 3.0
weight = 2.0
prediction = x * weight
print("Prediksi:", prediction)'''),
            ("menghitung_mse", "Mengukur rata-rata kuadrat selisih antara prediksi dan nilai sebenarnya.", '''actual = [2.0, 4.0, 6.0]
predicted = [2.5, 3.5, 5.0]
errors_squared = [(a - p) ** 2 for a, p in zip(actual, predicted)]
mse = sum(errors_squared) / len(actual)
print("MSE:", round(mse, 3))'''),
            ("alur_kerja_model", "Mencetak urutan dasar proses machine learning dari data sampai evaluasi.", '''steps = ["siapkan data", "latih model", "buat prediksi", "evaluasi hasil"]
for number, step in enumerate(steps, start=1):
    print(f"{number}. {step}")'''),
        ],
        "exercise": "Sebutkan contoh data masukan dan target yang mungkin dipakai untuk memprediksi harga rumah.",
    },
    {
        "title": "Dasar Python untuk Data",
        "summary": "Sebelum membangun jaringan saraf, kita perlu nyaman dengan list, perulangan, fungsi, dan operasi angka. List Python cukup untuk mengenalkan vektor dan matriks kecil.",
        "goals": ["Menerapkan operasi sederhana pada vektor.", "Memahami hasil kali titik dan bentuk matriks."],
        "terms": "list, vektor, matriks, fungsi, dimensi",
        "examples": [
            ("penjumlahan_vektor", "Menjumlahkan dua vektor elemen demi elemen.", '''a = [1, 2, 3]
b = [4, 5, 6]
result = [x + y for x, y in zip(a, b)]
print(result)'''),
            ("dot_product", "Menghitung hasil kali titik, operasi yang sering muncul pada neuron.", '''def dot_product(a, b):
    return sum(x * y for x, y in zip(a, b))

inputs = [2, 3]
weights = [0.5, 1.5]
print("Hasil:", dot_product(inputs, weights))'''),
            ("transpose_matriks", "Mengubah baris menjadi kolom pada matriks kecil.", '''matrix = [[1, 2, 3], [4, 5, 6]]
transposed = [list(column) for column in zip(*matrix)]
print(transposed)'''),
        ],
        "exercise": "Buat dua list berisi tiga angka, lalu jumlahkan kedua list tersebut tanpa mengubah nilai awal.",
    },
    {
        "title": "Data dan Pra-pemrosesan",
        "summary": "Model belajar dari contoh. Data perlu disusun dengan konsisten; skala fitur dapat diseragamkan, data dapat dibagi untuk pengujian, dan label kategori dapat diubah menjadi angka.",
        "goals": ["Melakukan normalisasi min-max sederhana.", "Memisahkan data secara berurutan dan membuat representasi one-hot."],
        "terms": "fitur, label, normalisasi, train set, test set, one-hot",
        "examples": [
            ("normalisasi_minmax", "Mengubah nilai ke rentang 0 sampai 1.", '''values = [10, 20, 30, 40]
minimum = min(values)
maximum = max(values)
normalized = [(value - minimum) / (maximum - minimum) for value in values]
print([round(value, 2) for value in normalized])'''),
            ("bagi_data", "Memisahkan contoh awal sebagai data latih dan sisanya sebagai data uji.", '''features = ["A", "B", "C", "D", "E"]
labels = [0, 1, 0, 1, 0]
split_at = 3
x_train, x_test = features[:split_at], features[split_at:]
y_train, y_test = labels[:split_at], labels[split_at:]
print("Latih:", x_train, y_train)
print("Uji:", x_test, y_test)'''),
            ("one_hot_encoding", "Mengubah label kategori menjadi vektor berisi nol dan satu.", '''labels = ["merah", "biru", "hijau"]
classes = ["merah", "hijau", "biru"]
encoded = [[int(label == item) for item in classes] for label in labels]
print(encoded)'''),
        ],
        "exercise": "Mengapa data uji sebaiknya tidak dipakai untuk memperbarui bobot saat pelatihan?",
    },
    {
        "title": "Neuron dan Perceptron",
        "summary": "Neuron buatan menggabungkan masukan dengan bobot, menambahkan bias, lalu menerapkan aturan aktivasi. Perceptron adalah model sederhana yang dapat mempelajari batas keputusan.",
        "goals": ["Menghitung jumlah berbobot dan bias.", "Melatih perceptron sederhana untuk gerbang logika AND."],
        "terms": "neuron, bobot, bias, threshold, perceptron",
        "examples": [
            ("fungsi_step", "Membuat fungsi aktivasi threshold yang menghasilkan kelas 0 atau 1.", '''def step(value):
    return 1 if value >= 0 else 0

for value in [-1.0, 0.0, 2.0]:
    print(value, "->", step(value))'''),
            ("satu_neuron", "Menghitung keluaran neuron dari dua masukan, bobot, dan bias.", '''inputs = [1.0, 2.0]
weights = [0.5, -0.25]
bias = 0.1
weighted_sum = sum(x * w for x, w in zip(inputs, weights)) + bias
output = 1 if weighted_sum >= 0 else 0
print("Jumlah berbobot:", weighted_sum)
print("Keluaran:", output)'''),
            ("latih_perceptron_and", "Memperbarui bobot perceptron sampai cocok dengan tabel kebenaran AND.", '''data = [([0, 0], 0), ([0, 1], 0), ([1, 0], 0), ([1, 1], 1)]
weights = [0.0, 0.0]
bias = 0.0
rate = 0.1
for _ in range(10):
    for inputs, target in data:
        prediction = int(sum(x * w for x, w in zip(inputs, weights)) + bias >= 0.5)
        error = target - prediction
        weights = [w + rate * error * x for w, x in zip(weights, inputs)]
        bias += rate * error
for inputs, target in data:
    prediction = int(sum(x * w for x, w in zip(inputs, weights)) + bias >= 0.5)
    print(inputs, "target=", target, "prediksi=", prediction)'''),
        ],
        "exercise": "Ubah contoh perceptron agar mempelajari gerbang OR. Catat perubahan targetnya.",
    },
    {
        "title": "Fungsi Aktivasi",
        "summary": "Fungsi aktivasi memberi sifat non-linear pada jaringan saraf. Tanpa non-linearitas, susunan banyak lapisan tetap setara dengan satu transformasi linear.",
        "goals": ["Mengenali ReLU, sigmoid, tanh, dan softmax.", "Memilih fungsi aktivasi sederhana sesuai keluaran yang diinginkan."],
        "terms": "ReLU, sigmoid, tanh, softmax, non-linear",
        "examples": [
            ("relu_sigmoid_tanh", "Membandingkan tiga aktivasi pada beberapa nilai.", '''import math

def relu(x):
    return max(0.0, x)

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

for value in [-2.0, 0.0, 2.0]:
    print(value, relu(value), round(sigmoid(value), 3), round(math.tanh(value), 3))'''),
            ("softmax", "Mengubah skor kelas menjadi nilai yang jumlahnya satu.", '''import math

scores = [2.0, 1.0, 0.1]
exp_scores = [math.exp(score) for score in scores]
total = sum(exp_scores)
probabilities = [score / total for score in exp_scores]
print([round(value, 3) for value in probabilities])
print("Jumlah:", round(sum(probabilities), 3))'''),
            ("relu_pada_list", "Menerapkan ReLU pada keluaran sejumlah neuron.", '''values = [-1.5, 0.2, 3.0, -0.1]
activated = [max(0.0, value) for value in values]
print(activated)'''),
        ],
        "exercise": "Untuk keluaran klasifikasi dua kelas, mengapa sigmoid dapat berguna?",
    },
    {
        "title": "Loss atau Fungsi Kerugian",
        "summary": "Loss adalah angka yang merangkum seberapa jauh prediksi model dari target. Proses pelatihan berusaha membuat loss semakin kecil.",
        "goals": ["Menghitung MAE dan MSE.", "Memahami cross-entropy untuk klasifikasi probabilistik."],
        "terms": "loss, MAE, MSE, cross-entropy, target",
        "examples": [
            ("mean_squared_error", "Menghitung MSE untuk masalah regresi.", '''actual = [1.0, 3.0, 5.0]
predicted = [1.5, 2.5, 4.0]
mse = sum((a - p) ** 2 for a, p in zip(actual, predicted)) / len(actual)
print("MSE:", round(mse, 3))'''),
            ("mean_absolute_error", "Menghitung rata-rata nilai absolut kesalahan.", '''actual = [1.0, 3.0, 5.0]
predicted = [1.5, 2.5, 4.0]
mae = sum(abs(a - p) for a, p in zip(actual, predicted)) / len(actual)
print("MAE:", round(mae, 3))'''),
            ("binary_cross_entropy", "Menghitung cross-entropy biner dengan probabilitas yang dibatasi agar log tetap terdefinisi.", '''import math

targets = [1, 0, 1]
probabilities = [0.9, 0.2, 0.6]
epsilon = 1e-7
losses = [-(y * math.log(p + epsilon) + (1 - y) * math.log(1 - p + epsilon))
          for y, p in zip(targets, probabilities)]
print("Binary cross-entropy:", round(sum(losses) / len(losses), 3))'''),
        ],
        "exercise": "Bandingkan MAE dan MSE ketika satu prediksi meleset sangat jauh. Ukuran mana yang lebih menghukum kesalahan besar?",
    },
    {
        "title": "Gradient Descent",
        "summary": "Gradient descent memperbarui parameter sedikit demi sedikit ke arah yang menurunkan loss. Learning rate mengatur besar langkah pembaruan.",
        "goals": ["Menggunakan turunan untuk memperbarui satu parameter.", "Melihat loss berkurang pada contoh regresi kecil."],
        "terms": "gradien, turunan, learning rate, epoch, parameter",
        "examples": [
            ("update_parameter", "Memperbarui parameter berdasarkan gradien dan learning rate.", '''parameter = 5.0
gradient = 4.0
learning_rate = 0.1
parameter = parameter - learning_rate * gradient
print("Parameter baru:", parameter)'''),
            ("latih_regresi_satu_parameter", "Mencari bobot garis sederhana dari pasangan data kecil.", '''x_values = [1.0, 2.0, 3.0]
y_values = [2.0, 4.0, 6.0]
weight = 0.0
learning_rate = 0.05
for epoch in range(100):
    gradient = sum(2 * x * (weight * x - y) for x, y in zip(x_values, y_values)) / len(x_values)
    weight -= learning_rate * gradient
print("Bobot yang dipelajari:", round(weight, 3))'''),
            ("pantau_loss", "Mencetak loss pada beberapa titik selama optimisasi.", '''x_values = [1.0, 2.0]
y_values = [2.0, 4.0]
weight = 0.0
learning_rate = 0.1
for epoch in range(11):
    loss = sum((weight * x - y) ** 2 for x, y in zip(x_values, y_values)) / len(x_values)
    if epoch in (0, 5, 10):
        print("epoch", epoch, "loss", round(loss, 4))
    gradient = sum(2 * x * (weight * x - y) for x, y in zip(x_values, y_values)) / len(x_values)
    weight -= learning_rate * gradient'''),
        ],
        "exercise": "Ubah learning rate pada contoh regresi. Amati apakah pelatihan menjadi lebih cepat atau tidak stabil.",
    },
    {
        "title": "Jaringan Saraf Multi-Lapisan",
        "summary": "Multi-layer perceptron (MLP) memiliki lapisan masukan, satu atau beberapa lapisan tersembunyi, dan lapisan keluaran. Prediksi dihitung dengan meneruskan nilai ke depan.",
        "goals": ["Melakukan forward pass pada satu lapisan.", "Memahami bahwa setiap lapisan menerima keluaran lapisan sebelumnya."],
        "terms": "MLP, forward pass, lapisan tersembunyi, dense layer",
        "examples": [
            ("forward_satu_neuron", "Menghitung satu neuron dengan aktivasi ReLU.", '''inputs = [0.5, 1.0]
weights = [0.8, -0.2]
bias = 0.1
z = sum(x * w for x, w in zip(inputs, weights)) + bias
output = max(0.0, z)
print("z:", round(z, 3), "output:", round(output, 3))'''),
            ("forward_satu_lapisan", "Menghitung keluaran dua neuron dari satu lapisan sederhana.", '''inputs = [1.0, 2.0]
weights = [[0.2, 0.4], [-0.5, 0.3]]
biases = [0.1, 0.0]
outputs = []
for neuron_weights, bias in zip(weights, biases):
    z = sum(x * w for x, w in zip(inputs, neuron_weights)) + bias
    outputs.append(max(0.0, z))
print(outputs)'''),
            ("forward_dua_lapisan", "Menyambungkan lapisan tersembunyi kecil dengan satu neuron keluaran.", '''inputs = [1.0, 0.5]
hidden_weights = [[0.2, 0.4], [0.6, -0.1]]
hidden = [max(0.0, sum(x * w for x, w in zip(inputs, row))) for row in hidden_weights]
output_weights = [0.7, -0.3]
output = sum(h * w for h, w in zip(hidden, output_weights))
print("Hidden:", hidden)
print("Output:", round(output, 3))'''),
        ],
        "exercise": "Tambahkan satu neuron pada lapisan tersembunyi dan sesuaikan jumlah bobot keluarannya.",
    },
    {
        "title": "Backpropagation Dasar",
        "summary": "Backpropagation menghitung bagaimana perubahan parameter memengaruhi loss, mulai dari keluaran dan bergerak mundur melalui jaringan dengan aturan rantai.",
        "goals": ["Memperkirakan gradien dengan selisih hingga.", "Menggunakan turunan sigmoid dan aturan rantai pada contoh kecil."],
        "terms": "backpropagation, aturan rantai, gradien, turunan",
        "examples": [
            ("gradien_numerik", "Mendekati turunan fungsi dengan selisih hingga.", '''def loss(weight):
    return (weight * 2 - 4) ** 2

weight = 1.0
epsilon = 1e-5
gradient = (loss(weight + epsilon) - loss(weight - epsilon)) / (2 * epsilon)
print("Perkiraan gradien:", round(gradient, 3))'''),
            ("turunan_sigmoid", "Menggunakan fakta sigmoid'(x) = sigmoid(x) * (1 - sigmoid(x)).", '''import math

x = 0.5
sigmoid = 1 / (1 + math.exp(-x))
derivative = sigmoid * (1 - sigmoid)
print("Sigmoid:", round(sigmoid, 3))
print("Turunan:", round(derivative, 3))'''),
            ("update_bobot_dari_error", "Mengalirkan error sederhana ke bobot menggunakan gradien loss kuadrat.", '''prediction = 0.7
target = 1.0
input_value = 2.0
weight = 0.3
learning_rate = 0.1
error = prediction - target
gradient = 2 * error * input_value
weight -= learning_rate * gradient
print("Bobot setelah pembaruan:", round(weight, 3))'''),
        ],
        "exercise": "Jelaskan dengan kata-kata sendiri mengapa informasi error perlu diteruskan ke lapisan sebelumnya.",
    },
    {
        "title": "Klasifikasi dengan Jaringan Saraf",
        "summary": "Pada klasifikasi, model memilih satu label dari beberapa kelas. Skor mentah dapat diubah menjadi probabilitas, lalu kelas dengan skor terbesar dipilih.",
        "goals": ["Mengubah skor menjadi prediksi kelas.", "Menghitung akurasi, presisi, dan recall dasar."],
        "terms": "klasifikasi, probabilitas kelas, akurasi, presisi, recall",
        "examples": [
            ("prediksi_argmax", "Memilih kelas dengan skor tertinggi.", '''scores = [0.2, 1.7, 0.8]
class_names = ["kucing", "anjing", "burung"]
predicted_index = max(range(len(scores)), key=scores.__getitem__)
print("Prediksi:", class_names[predicted_index])'''),
            ("hitung_akurasi", "Menghitung proporsi prediksi yang benar.", '''actual = [1, 0, 1, 1, 0]
predicted = [1, 0, 0, 1, 0]
correct = sum(a == p for a, p in zip(actual, predicted))
accuracy = correct / len(actual)
print("Akurasi:", round(accuracy, 2))'''),
            ("precision_recall", "Menghitung precision dan recall untuk kelas positif biner.", '''actual = [1, 0, 1, 1, 0]
predicted = [1, 1, 1, 0, 0]
true_positive = sum(a == 1 and p == 1 for a, p in zip(actual, predicted))
false_positive = sum(a == 0 and p == 1 for a, p in zip(actual, predicted))
false_negative = sum(a == 1 and p == 0 for a, p in zip(actual, predicted))
precision = true_positive / (true_positive + false_positive)
recall = true_positive / (true_positive + false_negative)
print("Precision:", round(precision, 2), "Recall:", round(recall, 2))'''),
        ],
        "exercise": "Pada kasus deteksi penyakit, pertimbangkan akibat false negative dan false positive. Metrik mana yang perlu diperhatikan?",
    },
    {
        "title": "Konsep CNN untuk Citra",
        "summary": "Convolutional neural network (CNN) memanfaatkan filter kecil untuk menemukan pola lokal pada citra. Berikut simulasi operasi dasar pada matriks angka, tanpa pustaka eksternal.",
        "goals": ["Menerapkan filter konvolusi sederhana.", "Memahami max pooling dan flattening."],
        "terms": "citra, kernel, konvolusi, pooling, feature map",
        "examples": [
            ("konvolusi_2d", "Menggeser kernel 2x2 pada matriks masukan kecil.", '''image = [[1, 2, 0], [0, 1, 3], [2, 1, 0]]
kernel = [[1, 0], [0, -1]]
feature_map = []
for row in range(len(image) - 1):
    output_row = []
    for column in range(len(image[0]) - 1):
        value = sum(image[row + i][column + j] * kernel[i][j]
                    for i in range(2) for j in range(2))
        output_row.append(value)
    feature_map.append(output_row)
print(feature_map)'''),
            ("max_pooling", "Mengambil nilai maksimum dari setiap area 2x2.", '''feature_map = [[1, 3, 2, 0], [4, 2, 1, 5], [0, 1, 7, 2], [3, 2, 4, 1]]
pooled = []
for row in range(0, 4, 2):
    pooled_row = []
    for column in range(0, 4, 2):
        block = [feature_map[row + i][column + j] for i in range(2) for j in range(2)]
        pooled_row.append(max(block))
    pooled.append(pooled_row)
print(pooled)'''),
            ("flatten_citra", "Meratakan matriks fitur menjadi satu vektor.", '''feature_map = [[1, 2], [3, 4]]
flattened = [value for row in feature_map for value in row]
print(flattened)'''),
        ],
        "exercise": "Ganti kernel pada contoh konvolusi. Pola apa yang ditonjolkan kernel baru?",
    },
    {
        "title": "Data Berurutan dan RNN",
        "summary": "Data berurutan memiliki urutan penting, misalnya teks atau deret waktu. RNN mempertahankan keadaan tersembunyi sederhana yang diperbarui setiap kali membaca elemen baru.",
        "goals": ["Membaca data sebagai urutan.", "Mensimulasikan state berulang dan prediksi nilai berikutnya."],
        "terms": "urutan, timestep, hidden state, RNN, deret waktu",
        "examples": [
            ("rata_rata_bergerak", "Menghitung rata-rata bergerak untuk deret waktu.", '''values = [10, 12, 14, 13, 15]
window = 3
averages = [sum(values[i:i + window]) / window for i in range(len(values) - window + 1)]
print(averages)'''),
            ("state_berulang", "Memperbarui satu state saat elemen urutan dibaca satu per satu.", '''sequence = [1, 2, 3, 4]
hidden_state = 0
for value in sequence:
    hidden_state = 0.5 * hidden_state + value
    print("input:", value, "state:", round(hidden_state, 2))'''),
            ("prediksi_nilai_berikutnya", "Memprediksi nilai berikutnya dengan pola selisih terakhir.", '''series = [3, 5, 7, 9]
last_change = series[-1] - series[-2]
next_value = series[-1] + last_change
print("Prediksi nilai berikutnya:", next_value)'''),
        ],
        "exercise": "Berikan contoh data yang urutannya penting dan contoh data yang urutannya tidak begitu penting.",
    },
    {
        "title": "Evaluasi dan Pencegahan Overfitting",
        "summary": "Model yang terlalu menghafal data latih dapat gagal pada data baru. Perbandingan loss latih dan validasi membantu mengenali masalah; regularisasi dan early stopping adalah teknik dasar untuk menguranginya.",
        "goals": ["Mengenali jarak antara loss latih dan validasi.", "Mensimulasikan penalti L2 dan early stopping."],
        "terms": "overfitting, validasi, regularisasi, L2, early stopping",
        "examples": [
            ("deteksi_gap_loss", "Memberi peringatan sederhana saat loss validasi jauh lebih besar.", '''train_loss = [0.8, 0.5, 0.3, 0.1]
validation_loss = [0.9, 0.6, 0.7, 1.0]
for epoch, (train, valid) in enumerate(zip(train_loss, validation_loss), start=1):
    status = "periksa kemungkinan overfitting" if valid > train + 0.3 else "wajar"
    print(epoch, status)'''),
            ("penalti_l2", "Menambahkan penalti kuadrat bobot pada loss.", '''data_loss = 0.25
weights = [0.5, -0.3, 0.2]
regularization_strength = 0.1
l2_penalty = regularization_strength * sum(weight ** 2 for weight in weights)
print("Loss total:", round(data_loss + l2_penalty, 3))'''),
            ("early_stopping", "Menghentikan pelatihan ketika loss validasi tidak membaik beberapa putaran.", '''validation_losses = [0.8, 0.6, 0.55, 0.57, 0.62]
best_loss = float("inf")
patience = 2
wait = 0
for epoch, loss in enumerate(validation_losses, start=1):
    if loss < best_loss:
        best_loss = loss
        wait = 0
    else:
        wait += 1
    print("epoch", epoch, "validation loss", loss)
    if wait == patience:
        print("Berhenti lebih awal")
        break'''),
        ],
        "exercise": "Mengapa loss validasi yang terus naik saat loss latih turun merupakan tanda bahaya?",
    },
    {
        "title": "Proyek Mini Klasifikasi AND",
        "summary": "Kita rangkai konsep data, neuron sigmoid, pelatihan dengan gradient descent, dan evaluasi pada proyek klasifikasi gerbang AND. Contoh tetap kecil agar setiap langkah dapat diperiksa.",
        "goals": ["Melatih model sigmoid satu neuron untuk data AND.", "Menguji prediksi serta menghitung akurasi."],
        "terms": "dataset kecil, sigmoid, training loop, prediksi, evaluasi",
        "examples": [
            ("siapkan_dataset_and", "Menampilkan fitur dan label untuk empat kombinasi masukan AND.", '''features = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
labels = [0.0, 0.0, 0.0, 1.0]
for inputs, label in zip(features, labels):
    print(inputs, "->", int(label))'''),
            ("latih_model_sigmoid_and", "Melatih satu neuron sigmoid dengan gradien untuk loss logistik.", '''import math

features = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
labels = [0.0, 0.0, 0.0, 1.0]
weights = [0.0, 0.0]
bias = 0.0
learning_rate = 0.5
for _ in range(3000):
    weight_gradients = [0.0, 0.0]
    bias_gradient = 0.0
    for inputs, target in zip(features, labels):
        z = sum(x * w for x, w in zip(inputs, weights)) + bias
        prediction = 1 / (1 + math.exp(-z))
        error = prediction - target
        for index, value in enumerate(inputs):
            weight_gradients[index] += error * value / len(features)
        bias_gradient += error / len(features)
    weights = [w - learning_rate * g for w, g in zip(weights, weight_gradients)]
    bias -= learning_rate * bias_gradient
print("Bobot:", [round(value, 2) for value in weights], "bias:", round(bias, 2))'''),
            ("evaluasi_model_and", "Menguji prediksi akhir dan menghitung akurasi model yang telah dilatih.", '''import math

features = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
labels = [0, 0, 0, 1]
weights = [4.0, 4.0]
bias = -6.0
predictions = []
for inputs in features:
    z = sum(x * w for x, w in zip(inputs, weights)) + bias
    probability = 1 / (1 + math.exp(-z))
    predictions.append(int(probability >= 0.5))
accuracy = sum(a == p for a, p in zip(labels, predictions)) / len(labels)
print("Prediksi:", predictions)
print("Akurasi:", round(accuracy, 2))'''),
        ],
        "exercise": "Modifikasi dataset dan target agar model belajar OR. Jelaskan apakah satu neuron masih cukup.",
    },
]


WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
ET.register_namespace("w", WORD_NS)


def make_paragraph(text, style="normal", code=False):
    paragraph = ET.Element(f"{{{WORD_NS}}}p")
    properties = ET.SubElement(paragraph, f"{{{WORD_NS}}}pPr")
    spacing = ET.SubElement(properties, f"{{{WORD_NS}}}spacing")
    spacing.set(f"{{{WORD_NS}}}after", "100" if code else "140")
    run = ET.SubElement(paragraph, f"{{{WORD_NS}}}r")
    run_properties = ET.SubElement(run, f"{{{WORD_NS}}}rPr")
    if code:
        fonts = ET.SubElement(run_properties, f"{{{WORD_NS}}}rFonts")
        fonts.set(f"{{{WORD_NS}}}ascii", "Consolas")
        fonts.set(f"{{{WORD_NS}}}hAnsi", "Consolas")
        size = "17"
        shade = ET.SubElement(run_properties, f"{{{WORD_NS}}}shd")
        shade.set(f"{{{WORD_NS}}}fill", "F1F4F7")
    elif style == "title":
        size = "34"
        ET.SubElement(run_properties, f"{{{WORD_NS}}}b")
        color = ET.SubElement(run_properties, f"{{{WORD_NS}}}color")
        color.set(f"{{{WORD_NS}}}val", "155B69")
    elif style.startswith("heading"):
        size = "26" if style == "heading1" else "22"
        ET.SubElement(run_properties, f"{{{WORD_NS}}}b")
        color = ET.SubElement(run_properties, f"{{{WORD_NS}}}color")
        color.set(f"{{{WORD_NS}}}val", "256875")
    else:
        size = "20"
    font_size = ET.SubElement(run_properties, f"{{{WORD_NS}}}sz")
    font_size.set(f"{{{WORD_NS}}}val", size)
    text_element = ET.SubElement(run, f"{{{WORD_NS}}}t")
    text_element.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    text_element.text = text if text else " "
    return paragraph


def write_docx(path, blocks):
    document = ET.Element(f"{{{WORD_NS}}}document")
    body = ET.SubElement(document, f"{{{WORD_NS}}}body")
    for text, style, code in blocks:
        body.append(make_paragraph(text, style, code))
    section = ET.SubElement(body, f"{{{WORD_NS}}}sectPr")
    page_size = ET.SubElement(section, f"{{{WORD_NS}}}pgSz")
    page_size.set(f"{{{WORD_NS}}}w", "12240")
    page_size.set(f"{{{WORD_NS}}}h", "15840")
    margins = ET.SubElement(section, f"{{{WORD_NS}}}pgMar")
    for side in ("top", "right", "bottom", "left"):
        margins.set(f"{{{WORD_NS}}}{side}", "900")

    content_types = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>'''
    package_rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>'''
    with ZipFile(path, "w", ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", package_rels)
        archive.writestr("word/document.xml", ET.tostring(document, encoding="utf-8", xml_declaration=True))


def build_lesson(index, lesson):
    number = f"{index:02d}"
    blocks = [(f"Modul {number}: {lesson['title']}", "title", False),
              ("Pembelajaran Deep Learning Dasar | S1 Informatika", "normal", False),
              ("Gambaran Materi", "heading1", False),
              (lesson["summary"], "normal", False),
              ("Tujuan Pembelajaran", "heading1", False)]
    for goal in lesson["goals"]:
        blocks.append(("• " + goal, "normal", False))
    blocks.extend([("Kata kunci: " + lesson["terms"], "normal", False),
                   ("Tiga Implementasi Python", "heading1", False)])
    for code_index, (slug, description, source) in enumerate(lesson["examples"], start=1):
        code_name = f"{number}_{code_index:02d}_{slug}.py"
        blocks.extend([(f"{code_index}. {slug.replace('_', ' ').title()}", "heading2", False),
                       (description, "normal", False),
                       (f"File terpisah: Kode_Python/{code_name}", "normal", False)])
        blocks.extend((line, "normal", True) for line in source.splitlines())
    blocks.extend([("Latihan Mandiri", "heading1", False),
                   (lesson["exercise"], "normal", False),
                   ("Ringkasan", "heading1", False),
                   (f"Pada modul ini kita mempelajari {lesson['terms']}. Jalankan setiap file Python, ubah satu nilai, lalu amati dampaknya pada keluaran.", "normal", False),
                   ("Prasyarat: Python 3.10 atau lebih baru. Contoh menggunakan pustaka standar Python.", "normal", False)])
    path = DOCS / f"{number}_{lesson['title'].lower().replace(' ', '_')}.docx"
    write_docx(path, blocks)

    for code_index, (slug, description, source) in enumerate(lesson["examples"], start=1):
        code_name = f"{number}_{code_index:02d}_{slug}.py"
        code_path = SCRIPTS / code_name
        code_path.write_text(
            f'"""{lesson["title"]}: {description}"""\n\n{source}\n',
            encoding="utf-8",
        )


def main():
    DOCS.mkdir(exist_ok=True)
    SCRIPTS.mkdir(exist_ok=True)
    for index, lesson in enumerate(LESSONS, start=1):
        build_lesson(index, lesson)
    print(f"Dokumen Word: {len(list(DOCS.glob('*.docx')))}")
    print(f"File Python: {len(list(SCRIPTS.glob('*.py')))}")
    print(f"Lokasi: {ROOT}")


if __name__ == "__main__":
    main()
