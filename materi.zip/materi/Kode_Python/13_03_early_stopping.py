"""Evaluasi dan Pencegahan Overfitting: Menghentikan pelatihan ketika loss validasi tidak membaik beberapa putaran."""

validation_losses = [0.8, 0.6, 0.55, 0.57, 0.62]
best_loss = float("inf")
patience = 2
wait = 0
for epoch, loss in enumerate(validation_losses, start=1):
    if loss < best_loss:
        best_loss = loss
        wait = 0
    else:
        wait += 1
    print("epoch", epoch, "validation loss", loss)
    if wait == patience:
        print("Berhenti lebih awal")
        break
