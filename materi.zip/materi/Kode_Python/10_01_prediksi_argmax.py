"""Klasifikasi dengan Jaringan Saraf: Memilih kelas dengan skor tertinggi."""

scores = [0.2, 1.7, 0.8]
class_names = ["kucing", "anjing", "burung"]
predicted_index = max(range(len(scores)), key=scores.__getitem__)
print("Prediksi:", class_names[predicted_index])
