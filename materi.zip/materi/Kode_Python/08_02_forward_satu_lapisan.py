"""Jaringan Saraf Multi-Lapisan: Menghitung keluaran dua neuron dari satu lapisan sederhana."""

inputs = [1.0, 2.0]
weights = [[0.2, 0.4], [-0.5, 0.3]]
biases = [0.1, 0.0]
outputs = []
for neuron_weights, bias in zip(weights, biases):
    z = sum(x * w for x, w in zip(inputs, neuron_weights)) + bias
    outputs.append(max(0.0, z))
print(outputs)
