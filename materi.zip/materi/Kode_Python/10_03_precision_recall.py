"""Klasifikasi dengan Jaringan Saraf: Menghitung precision dan recall untuk kelas positif biner."""

actual = [1, 0, 1, 1, 0]
predicted = [1, 1, 1, 0, 0]
true_positive = sum(a == 1 and p == 1 for a, p in zip(actual, predicted))
false_positive = sum(a == 0 and p == 1 for a, p in zip(actual, predicted))
false_negative = sum(a == 1 and p == 0 for a, p in zip(actual, predicted))
precision = true_positive / (true_positive + false_positive)
recall = true_positive / (true_positive + false_negative)
print("Precision:", round(precision, 2), "Recall:", round(recall, 2))
