"""Evaluasi dan Pencegahan Overfitting: Menambahkan penalti kuadrat bobot pada loss."""

data_loss = 0.25
weights = [0.5, -0.3, 0.2]
regularization_strength = 0.1
l2_penalty = regularization_strength * sum(weight ** 2 for weight in weights)
print("Loss total:", round(data_loss + l2_penalty, 3))
