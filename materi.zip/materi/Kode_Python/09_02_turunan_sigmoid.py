"""Backpropagation Dasar: Menggunakan fakta sigmoid'(x) = sigmoid(x) * (1 - sigmoid(x))."""

import math

x = 0.5
sigmoid = 1 / (1 + math.exp(-x))
derivative = sigmoid * (1 - sigmoid)
print("Sigmoid:", round(sigmoid, 3))
print("Turunan:", round(derivative, 3))
