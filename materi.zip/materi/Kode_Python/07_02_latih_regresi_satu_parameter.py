"""Gradient Descent: Mencari bobot garis sederhana dari pasangan data kecil."""

x_values = [1.0, 2.0, 3.0]
y_values = [2.0, 4.0, 6.0]
weight = 0.0
learning_rate = 0.05
for epoch in range(100):
    gradient = sum(2 * x * (weight * x - y) for x, y in zip(x_values, y_values)) / len(x_values)
    weight -= learning_rate * gradient
print("Bobot yang dipelajari:", round(weight, 3))
