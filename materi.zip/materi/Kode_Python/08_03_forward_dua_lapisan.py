"""Jaringan Saraf Multi-Lapisan: Menyambungkan lapisan tersembunyi kecil dengan satu neuron keluaran."""

inputs = [1.0, 0.5]
hidden_weights = [[0.2, 0.4], [0.6, -0.1]]
hidden = [max(0.0, sum(x * w for x, w in zip(inputs, row))) for row in hidden_weights]
output_weights = [0.7, -0.3]
output = sum(h * w for h, w in zip(hidden, output_weights))
print("Hidden:", hidden)
print("Output:", round(output, 3))
