"""Mengenal Deep Learning: Melihat bagaimana satu masukan dikalikan bobot untuk menghasilkan prediksi sederhana."""

x = 3.0
weight = 2.0
prediction = x * weight
print("Prediksi:", prediction)
