"""Mengenal Deep Learning: Mengukur rata-rata kuadrat selisih antara prediksi dan nilai sebenarnya."""

actual = [2.0, 4.0, 6.0]
predicted = [2.5, 3.5, 5.0]
errors_squared = [(a - p) ** 2 for a, p in zip(actual, predicted)]
mse = sum(errors_squared) / len(actual)
print("MSE:", round(mse, 3))
