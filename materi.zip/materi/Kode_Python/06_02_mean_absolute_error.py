"""Loss atau Fungsi Kerugian: Menghitung rata-rata nilai absolut kesalahan."""

actual = [1.0, 3.0, 5.0]
predicted = [1.5, 2.5, 4.0]
mae = sum(abs(a - p) for a, p in zip(actual, predicted)) / len(actual)
print("MAE:", round(mae, 3))
