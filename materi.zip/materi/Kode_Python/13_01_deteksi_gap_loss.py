"""Evaluasi dan Pencegahan Overfitting: Memberi peringatan sederhana saat loss validasi jauh lebih besar."""

train_loss = [0.8, 0.5, 0.3, 0.1]
validation_loss = [0.9, 0.6, 0.7, 1.0]
for epoch, (train, valid) in enumerate(zip(train_loss, validation_loss), start=1):
    status = "periksa kemungkinan overfitting" if valid > train + 0.3 else "wajar"
    print(epoch, status)
