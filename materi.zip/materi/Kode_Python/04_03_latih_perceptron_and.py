"""Neuron dan Perceptron: Memperbarui bobot perceptron sampai cocok dengan tabel kebenaran AND."""

data = [([0, 0], 0), ([0, 1], 0), ([1, 0], 0), ([1, 1], 1)]
weights = [0.0, 0.0]
bias = 0.0
rate = 0.1
for _ in range(10):
    for inputs, target in data:
        prediction = int(sum(x * w for x, w in zip(inputs, weights)) + bias >= 0.5)
        error = target - prediction
        weights = [w + rate * error * x for w, x in zip(weights, inputs)]
        bias += rate * error
for inputs, target in data:
    prediction = int(sum(x * w for x, w in zip(inputs, weights)) + bias >= 0.5)
    print(inputs, "target=", target, "prediksi=", prediction)
