"""Data dan Pra-pemrosesan: Mengubah nilai ke rentang 0 sampai 1."""

values = [10, 20, 30, 40]
minimum = min(values)
maximum = max(values)
normalized = [(value - minimum) / (maximum - minimum) for value in values]
print([round(value, 2) for value in normalized])
