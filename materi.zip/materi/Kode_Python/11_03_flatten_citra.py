"""Konsep CNN untuk Citra: Meratakan matriks fitur menjadi satu vektor."""

feature_map = [[1, 2], [3, 4]]
flattened = [value for row in feature_map for value in row]
print(flattened)
