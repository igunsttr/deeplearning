"""Data dan Pra-pemrosesan: Mengubah label kategori menjadi vektor berisi nol dan satu."""

labels = ["merah", "biru", "hijau"]
classes = ["merah", "hijau", "biru"]
encoded = [[int(label == item) for item in classes] for label in labels]
print(encoded)
