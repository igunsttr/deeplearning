"""Proyek Mini Klasifikasi AND: Menguji prediksi akhir dan menghitung akurasi model yang telah dilatih."""

import math

features = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
labels = [0, 0, 0, 1]
weights = [4.0, 4.0]
bias = -6.0
predictions = []
for inputs in features:
    z = sum(x * w for x, w in zip(inputs, weights)) + bias
    probability = 1 / (1 + math.exp(-z))
    predictions.append(int(probability >= 0.5))
accuracy = sum(a == p for a, p in zip(labels, predictions)) / len(labels)
print("Prediksi:", predictions)
print("Akurasi:", round(accuracy, 2))
