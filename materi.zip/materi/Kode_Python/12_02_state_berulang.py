"""Data Berurutan dan RNN: Memperbarui satu state saat elemen urutan dibaca satu per satu."""

sequence = [1, 2, 3, 4]
hidden_state = 0
for value in sequence:
    hidden_state = 0.5 * hidden_state + value
    print("input:", value, "state:", round(hidden_state, 2))
