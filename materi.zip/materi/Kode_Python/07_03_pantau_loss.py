"""Gradient Descent: Mencetak loss pada beberapa titik selama optimisasi."""

x_values = [1.0, 2.0]
y_values = [2.0, 4.0]
weight = 0.0
learning_rate = 0.1
for epoch in range(11):
    loss = sum((weight * x - y) ** 2 for x, y in zip(x_values, y_values)) / len(x_values)
    if epoch in (0, 5, 10):
        print("epoch", epoch, "loss", round(loss, 4))
    gradient = sum(2 * x * (weight * x - y) for x, y in zip(x_values, y_values)) / len(x_values)
    weight -= learning_rate * gradient
