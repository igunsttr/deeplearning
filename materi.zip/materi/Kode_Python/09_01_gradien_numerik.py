"""Backpropagation Dasar: Mendekati turunan fungsi dengan selisih hingga."""

def loss(weight):
    return (weight * 2 - 4) ** 2

weight = 1.0
epsilon = 1e-5
gradient = (loss(weight + epsilon) - loss(weight - epsilon)) / (2 * epsilon)
print("Perkiraan gradien:", round(gradient, 3))
