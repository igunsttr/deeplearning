"""Data Berurutan dan RNN: Menghitung rata-rata bergerak untuk deret waktu."""

values = [10, 12, 14, 13, 15]
window = 3
averages = [sum(values[i:i + window]) / window for i in range(len(values) - window + 1)]
print(averages)
