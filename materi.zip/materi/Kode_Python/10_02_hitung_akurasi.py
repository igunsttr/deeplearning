"""Klasifikasi dengan Jaringan Saraf: Menghitung proporsi prediksi yang benar."""

actual = [1, 0, 1, 1, 0]
predicted = [1, 0, 0, 1, 0]
correct = sum(a == p for a, p in zip(actual, predicted))
accuracy = correct / len(actual)
print("Akurasi:", round(accuracy, 2))
