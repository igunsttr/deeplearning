"""Neuron dan Perceptron: Membuat fungsi aktivasi threshold yang menghasilkan kelas 0 atau 1."""

def step(value):
    return 1 if value >= 0 else 0

for value in [-1.0, 0.0, 2.0]:
    print(value, "->", step(value))
