"""Backpropagation Dasar: Mengalirkan error sederhana ke bobot menggunakan gradien loss kuadrat."""

prediction = 0.7
target = 1.0
input_value = 2.0
weight = 0.3
learning_rate = 0.1
error = prediction - target
gradient = 2 * error * input_value
weight -= learning_rate * gradient
print("Bobot setelah pembaruan:", round(weight, 3))
