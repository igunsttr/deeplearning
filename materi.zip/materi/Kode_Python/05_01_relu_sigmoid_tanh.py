"""Fungsi Aktivasi: Membandingkan tiga aktivasi pada beberapa nilai."""

import math

def relu(x):
    return max(0.0, x)

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

for value in [-2.0, 0.0, 2.0]:
    print(value, relu(value), round(sigmoid(value), 3), round(math.tanh(value), 3))
