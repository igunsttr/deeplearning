"""Loss atau Fungsi Kerugian: Menghitung cross-entropy biner dengan probabilitas yang dibatasi agar log tetap terdefinisi."""

import math

targets = [1, 0, 1]
probabilities = [0.9, 0.2, 0.6]
epsilon = 1e-7
losses = [-(y * math.log(p + epsilon) + (1 - y) * math.log(1 - p + epsilon))
          for y, p in zip(targets, probabilities)]
print("Binary cross-entropy:", round(sum(losses) / len(losses), 3))
