"""Fungsi Aktivasi: Mengubah skor kelas menjadi nilai yang jumlahnya satu."""

import math

scores = [2.0, 1.0, 0.1]
exp_scores = [math.exp(score) for score in scores]
total = sum(exp_scores)
probabilities = [score / total for score in exp_scores]
print([round(value, 3) for value in probabilities])
print("Jumlah:", round(sum(probabilities), 3))
