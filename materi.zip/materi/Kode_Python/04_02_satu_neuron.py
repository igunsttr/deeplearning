"""Neuron dan Perceptron: Menghitung keluaran neuron dari dua masukan, bobot, dan bias."""

inputs = [1.0, 2.0]
weights = [0.5, -0.25]
bias = 0.1
weighted_sum = sum(x * w for x, w in zip(inputs, weights)) + bias
output = 1 if weighted_sum >= 0 else 0
print("Jumlah berbobot:", weighted_sum)
print("Keluaran:", output)
