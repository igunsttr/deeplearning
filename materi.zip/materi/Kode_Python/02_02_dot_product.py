"""Dasar Python untuk Data: Menghitung hasil kali titik, operasi yang sering muncul pada neuron."""

def dot_product(a, b):
    return sum(x * y for x, y in zip(a, b))

inputs = [2, 3]
weights = [0.5, 1.5]
print("Hasil:", dot_product(inputs, weights))
