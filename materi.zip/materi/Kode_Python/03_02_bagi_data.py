"""Data dan Pra-pemrosesan: Memisahkan contoh awal sebagai data latih dan sisanya sebagai data uji."""

features = ["A", "B", "C", "D", "E"]
labels = [0, 1, 0, 1, 0]
split_at = 3
x_train, x_test = features[:split_at], features[split_at:]
y_train, y_test = labels[:split_at], labels[split_at:]
print("Latih:", x_train, y_train)
print("Uji:", x_test, y_test)
