"""Konsep CNN untuk Citra: Menggeser kernel 2x2 pada matriks masukan kecil."""

image = [[1, 2, 0], [0, 1, 3], [2, 1, 0]]
kernel = [[1, 0], [0, -1]]
feature_map = []
for row in range(len(image) - 1):
    output_row = []
    for column in range(len(image[0]) - 1):
        value = sum(image[row + i][column + j] * kernel[i][j]
                    for i in range(2) for j in range(2))
        output_row.append(value)
    feature_map.append(output_row)
print(feature_map)
