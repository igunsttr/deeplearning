"""Jaringan Saraf Multi-Lapisan: Menghitung satu neuron dengan aktivasi ReLU."""

inputs = [0.5, 1.0]
weights = [0.8, -0.2]
bias = 0.1
z = sum(x * w for x, w in zip(inputs, weights)) + bias
output = max(0.0, z)
print("z:", round(z, 3), "output:", round(output, 3))
