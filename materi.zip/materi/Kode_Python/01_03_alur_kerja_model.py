"""Mengenal Deep Learning: Mencetak urutan dasar proses machine learning dari data sampai evaluasi."""

steps = ["siapkan data", "latih model", "buat prediksi", "evaluasi hasil"]
for number, step in enumerate(steps, start=1):
    print(f"{number}. {step}")
