"""Gradient Descent: Memperbarui parameter berdasarkan gradien dan learning rate."""

parameter = 5.0
gradient = 4.0
learning_rate = 0.1
parameter = parameter - learning_rate * gradient
print("Parameter baru:", parameter)
