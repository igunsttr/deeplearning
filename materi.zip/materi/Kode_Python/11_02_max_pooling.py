"""Konsep CNN untuk Citra: Mengambil nilai maksimum dari setiap area 2x2."""

feature_map = [[1, 3, 2, 0], [4, 2, 1, 5], [0, 1, 7, 2], [3, 2, 4, 1]]
pooled = []
for row in range(0, 4, 2):
    pooled_row = []
    for column in range(0, 4, 2):
        block = [feature_map[row + i][column + j] for i in range(2) for j in range(2)]
        pooled_row.append(max(block))
    pooled.append(pooled_row)
print(pooled)
