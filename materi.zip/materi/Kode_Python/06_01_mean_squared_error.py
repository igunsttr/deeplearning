"""Loss atau Fungsi Kerugian: Menghitung MSE untuk masalah regresi."""

actual = [1.0, 3.0, 5.0]
predicted = [1.5, 2.5, 4.0]
mse = sum((a - p) ** 2 for a, p in zip(actual, predicted)) / len(actual)
print("MSE:", round(mse, 3))
