"""Fungsi Aktivasi: Menerapkan ReLU pada keluaran sejumlah neuron."""

values = [-1.5, 0.2, 3.0, -0.1]
activated = [max(0.0, value) for value in values]
print(activated)
