"""Data Berurutan dan RNN: Memprediksi nilai berikutnya dengan pola selisih terakhir."""

series = [3, 5, 7, 9]
last_change = series[-1] - series[-2]
next_value = series[-1] + last_change
print("Prediksi nilai berikutnya:", next_value)
