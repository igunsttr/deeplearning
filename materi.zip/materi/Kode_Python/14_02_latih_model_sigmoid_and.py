"""Proyek Mini Klasifikasi AND: Melatih satu neuron sigmoid dengan gradien untuk loss logistik."""

import math

features = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
labels = [0.0, 0.0, 0.0, 1.0]
weights = [0.0, 0.0]
bias = 0.0
learning_rate = 0.5
for _ in range(3000):
    weight_gradients = [0.0, 0.0]
    bias_gradient = 0.0
    for inputs, target in zip(features, labels):
        z = sum(x * w for x, w in zip(inputs, weights)) + bias
        prediction = 1 / (1 + math.exp(-z))
        error = prediction - target
        for index, value in enumerate(inputs):
            weight_gradients[index] += error * value / len(features)
        bias_gradient += error / len(features)
    weights = [w - learning_rate * g for w, g in zip(weights, weight_gradients)]
    bias -= learning_rate * bias_gradient
print("Bobot:", [round(value, 2) for value in weights], "bias:", round(bias, 2))
