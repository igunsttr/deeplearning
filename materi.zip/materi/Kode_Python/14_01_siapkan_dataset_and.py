"""Proyek Mini Klasifikasi AND: Menampilkan fitur dan label untuk empat kombinasi masukan AND."""

features = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
labels = [0.0, 0.0, 0.0, 1.0]
for inputs, label in zip(features, labels):
    print(inputs, "->", int(label))
