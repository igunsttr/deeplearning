"""Dasar Python untuk Data: Menjumlahkan dua vektor elemen demi elemen."""

a = [1, 2, 3]
b = [4, 5, 6]
result = [x + y for x, y in zip(a, b)]
print(result)
